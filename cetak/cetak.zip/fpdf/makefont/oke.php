<?php
require('makefont.php');

MakeFont('Tomatoes-O8L8.ttf','cp1252');
?>